<style>
    /* PRELOADER STYLES */
    #global-preloader {
        position: fixed;
        inset: 0;
        z-index: 9999;
        background-color: #0f0216;
        display: flex;
        justify-content: center;
        align-items: center;
        transition: opacity 0.5s ease;
    }
    .preloader-rocket-container {
        position: absolute;
        transform: translateY(-120vh);
        opacity: 0;
    }
    .preloader-rocket-container.landed {
        opacity: 1;
        animation: rocketLand 1.4s cubic-bezier(0.25, 1, 0.5, 1) forwards;
    }
    @keyframes rocketLand {
        0% { transform: translateY(-120vh) scale(1.3); }
        80% { transform: translateY(-10px) scale(1); } 
        100% { transform: translateY(0) scale(1); } 
    }
    .preloader-flame { transform-origin: top center; animation: flicker 0.05s infinite alternate; }
    .preloader-flame.extinguish { animation: killFlame 0.15s forwards; }
    @keyframes flicker { 0% { transform: scaleY(0.8); opacity: 0.8; } 100% { transform: scaleY(1.3); opacity: 1; } }
    @keyframes killFlame { to { transform: scaleY(0); opacity: 0; } }

    .preloader-dust-ring {
        position: absolute;
        width: 120px; height: 30px;
        border: 2px solid #BFF747;
        border-radius: 50%;
        transform: translate(-30px, 40px) scale(0);
        opacity: 0;
    }
    .preloader-dust-ring.expand { animation: dustExpand 0.7s ease-out forwards; }
    @keyframes dustExpand {
        0% { transform: translate(-30px, 40px) scale(0); opacity: 1; border-width: 3px; }
        100% { transform: translate(-30px, 40px) scale(2.5); opacity: 0; border-width: 0px; }
    }

    /* SIDEBAR STYLES */
    @keyframes slowFloat {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-8px); }
    }
    .rocket-float {
        animation: slowFloat 4s ease-in-out infinite;
    }
    .nav-item {
        position: relative;
        transition: all 0.3s ease;
    }
    .nav-item:hover {
        color: #BFF747;
        padding-left: 0.5rem;
    }
    .nav-item::before {
        content: '';
        position: absolute;
        left: -1rem;
        top: 50%;
        transform: translateY(-50%);
        width: 6px;
        height: 6px;
        background-color: #BFF747;
        border-radius: 50%;
        opacity: 0;
        transition: all 0.3s ease;
    }
    .nav-item:hover::before {
        opacity: 1;
        left: -0.5rem;
    }
</style>

<div id="global-preloader">
    <div class="preloader-rocket-container" id="preloader-rocket">
        <svg width="60" height="100" viewBox="0 0 60 100">
            <path d="M30 0 C45 20 45 60 45 70 L15 70 C15 60 15 20 30 0Z" fill="rgba(191,247,71,0.1)" stroke="#BFF747" stroke-width="2"/>
            <path d="M15 50 L0 80 L15 70 Z" fill="#BFF747"/>
            <path d="M45 50 L60 80 L45 70 Z" fill="#BFF747"/>
            <circle cx="30" cy="35" r="7" fill="#0f0216" stroke="#BFF747" stroke-width="2"/>
            <path class="preloader-flame" id="preloader-flame" d="M26 80 L34 80 L30 100 Z" fill="#BFF747"/>
        </svg>
        <div class="preloader-dust-ring" id="preloader-dust"></div>
    </div>
</div>

<div class="md:hidden fixed top-0 left-0 w-full h-16 bg-[#0a010e]/90 backdrop-blur-md border-b border-[#BFF747]/20 flex items-center justify-between px-6 z-40">
    <h2 class="text-xl font-bold text-white tracking-wider">Code<span class="text-[#BFF747]">Orbit</span></h2>
    <button id="mobileMenuBtn" class="text-[#BFF747] focus:outline-none p-2">
        <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
    </button>
</div>

<div id="sidebarOverlay" class="fixed inset-0 bg-[#0f0216]/80 backdrop-blur-sm z-40 hidden opacity-0 transition-opacity duration-300 md:hidden"></div>

<aside id="sidebar" class="w-64 h-screen fixed left-0 top-0 bg-[#0a010e] border-r border-[#BFF747]/20 flex flex-col pt-10 z-50 transform -translate-x-full md:translate-x-0 transition-transform duration-300 ease-in-out overflow-y-auto">
    
    <button id="closeMenuBtn" class="md:hidden absolute top-4 right-4 text-[#a097a6] hover:text-[#BFF747] focus:outline-none p-2">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
    </button>

    <div class="flex flex-col items-center justify-center mt-4 md:mt-0 mb-10 rocket-float">
        <svg width="40" height="65" viewBox="0 0 60 100" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-4">
            <path d="M30 0 C45 20 45 60 45 70 L15 70 C15 60 15 20 30 0Z" fill="rgba(191,247,71,0.1)" stroke="#BFF747" stroke-width="2"/>
            <path d="M15 50 L0 80 L15 70 Z" fill="#BFF747"/>
            <path d="M45 50 L60 80 L45 70 Z" fill="#BFF747"/>
            <circle cx="30" cy="35" r="7" fill="#0f0216" stroke="#BFF747" stroke-width="2"/>
            <path d="M26 80 L34 80 L30 100 Z" fill="#BFF747" filter="drop-shadow(0 0 5px #BFF747)"/>
        </svg>
        <h2 class="text-2xl font-bold text-white tracking-wider hidden md:block">Code<span class="text-[#BFF747]">Orbit</span></h2>
    </div>

    <nav class="flex flex-col space-y-5 px-8 text-[#a097a6] font-medium flex-grow">
        <a href="/" class="nav-item">Home</a>
        <a href="/about" class="nav-item">About</a>
        <a href="/courses" class="nav-item">Courses</a>
        <a href="/practice" class="nav-item">Practice Questions</a>
        <a href="/systemdesign" class="nav-item">System Design</a>
        <a href="/contact" class="nav-item">Contact</a>
    </nav>

    <div class="px-6 pb-8 pt-6 mt-4 border-t border-white/10 bg-white/5">
        <p class="text-white font-bold text-sm tracking-wide mb-1">Rahul Kalita</p>
        <p class="text-[#a097a6] text-xs font-mono mb-4 flex items-center gap-2">
            <svg class="w-3 h-3 text-[#BFF747]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg> 
            +91 6003632275
        </p>
        <div class="flex gap-4">
            <a href="https://www.linkedin.com/in/rahul-kalita-bab402240" target="_blank" class="text-[#a097a6] hover:text-[#BFF747] transition-colors" title="LinkedIn">
                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
            </a>
            <a href="https://x.com/Rahul89007335" target="_blank" class="text-[#a097a6] hover:text-[#BFF747] transition-colors" title="X (Twitter)">
                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
            </a>
        </div>
    </div>
</aside>

<script>
    // DYNAMIC FAVICON INJECTION
    // This dynamically adds a matching CodeOrbit rocket SVG as the favicon to any page that includes this sidebar.
    if (!document.querySelector("link[rel*='icon']")) {
        const favicon = document.createElement('link');
        favicon.rel = 'icon';
        favicon.type = 'image/svg+xml';
        favicon.href = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='46' fill='%230a010e' stroke='%23BFF747' stroke-width='6'/%3E%3Cpath d='M50 20 C 60 40 60 70 60 80 L 40 80 C 40 70 40 40 50 20 Z' fill='rgba(191,247,71,0.2)'/%3E%3Cpath d='M40 60 L 25 90 L 40 80 Z' fill='%23BFF747'/%3E%3Cpath d='M60 60 L 75 90 L 60 80 Z' fill='%23BFF747'/%3E%3Cpath d='M50 20 L 60 80 L 40 80 Z' fill='%23BFF747'/%3E%3Ccircle cx='50' cy='45' r='6' fill='%230a010e'/%3E%3C/svg%3E";
        document.head.appendChild(favicon);
    }

    // PRELOADER LOGIC
    window.addEventListener('load', () => {
        const rocket = document.getElementById('preloader-rocket');
        const flame = document.getElementById('preloader-flame');
        const dust = document.getElementById('preloader-dust');
        const preloader = document.getElementById('global-preloader');
        
        // Start landing immediately on load
        if(rocket) rocket.classList.add('landed');
        
        // Extinguish flame and expand dust
        setTimeout(() => {
            if(flame) flame.classList.add('extinguish');
            if(dust) dust.classList.add('expand');
        }, 1400);

        // Fade out and remove preloader
        setTimeout(() => {
            if(preloader) {
                preloader.style.opacity = '0';
                setTimeout(() => preloader.remove(), 500);
            }
        }, 1900);
    });

    // MOBILE MENU LOGIC
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const closeMenuBtn = document.getElementById('closeMenuBtn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    function toggleMenu() {
        const isClosed = sidebar.classList.contains('-translate-x-full');
        
        if (isClosed) {
            sidebar.classList.remove('-translate-x-full');
            overlay.classList.remove('hidden');
            setTimeout(() => overlay.classList.remove('opacity-0'), 10);
            document.body.style.overflow = 'hidden';
        } else {
            sidebar.classList.add('-translate-x-full');
            overlay.classList.add('opacity-0');
            setTimeout(() => overlay.classList.add('hidden'), 300);
            document.body.style.overflow = '';
        }
    }

    if(mobileMenuBtn) mobileMenuBtn.addEventListener('click', toggleMenu);
    if(closeMenuBtn) closeMenuBtn.addEventListener('click', toggleMenu);
    if(overlay) overlay.addEventListener('click', toggleMenu);
</script>