<footer class="border-t border-white/10 bg-[#0a010e] pt-16 pb-8 px-6 md:px-12 relative z-10">
    <div class="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
        
        <div class="md:col-span-1 flex flex-col items-start">
            <h2 class="text-2xl font-bold text-white tracking-wider mb-4">Code<span class="text-[#BFF747]">Orbit</span></h2>
            <p class="text-[#a097a6] text-sm leading-relaxed mb-6">
                Master complex programming theory through interactive, space-themed exploration.
            </p>
            <div class="flex gap-4">
                <a href="https://www.linkedin.com/in/rahul-kalita-bab402240" target="_blank" class="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-[#a097a6] hover:text-[#0f0216] hover:bg-[#BFF747] transition-all">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                </a>
                <a href="https://x.com/Rahul89007335" target="_blank" class="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-[#a097a6] hover:text-[#0f0216] hover:bg-[#BFF747] transition-all">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                </a>
            </div>
        </div>

        <div>
            <h3 class="text-white font-bold mb-4 uppercase text-xs tracking-widest">Navigation</h3>
            <ul class="space-y-3 text-sm text-[#a097a6]">
                <li><a href="/" class="hover:text-[#BFF747] transition-colors">Home Base</a></li>
                <li><a href="/about" class="hover:text-[#BFF747] transition-colors">About Us</a></li>
                <li><a href="/courses" class="hover:text-[#BFF747] transition-colors">Mission Dashboard</a></li>
                <li><a href="/systemdesign" class="hover:text-[#BFF747] transition-colors">Architecture Deck</a></li>
            </ul>
        </div>

        <div>
            <h3 class="text-white font-bold mb-4 uppercase text-xs tracking-widest">Legal</h3>
            <ul class="space-y-3 text-sm text-[#a097a6]">
                <li><a href="#" class="hover:text-[#BFF747] transition-colors">Privacy Policy</a></li>
                <li><a href="#" class="hover:text-[#BFF747] transition-colors">Terms of Service</a></li>
                <li><a href="#" class="hover:text-[#BFF747] transition-colors">Cookie Policy</a></li>
            </ul>
        </div>

        <div>
            <h3 class="text-white font-bold mb-4 uppercase text-xs tracking-widest">Direct Comms</h3>
            <ul class="space-y-3 text-sm text-[#a097a6]">
                <li>Commander: Rahul Kalita</li>
                <li class="font-mono text-[#BFF747]">+91 6003632275</li>
                <li><a href="/contact" class="hover:text-white transition-colors underline decoration-white/30 underline-offset-4">Establish Contact &rarr;</a></li>
            </ul>
        </div>
    </div>
    
    <div class="max-w-6xl mx-auto border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
        <p class="text-[#a097a6] text-xs">© <?php echo date('Y'); ?> CodeOrbit. All rights reserved in this galaxy.</p>
        <p class="text-[#a097a6] text-xs flex items-center gap-1">Built with <span class="text-red-500">♥</span> for the JS Community</p>
    </div>
</footer>