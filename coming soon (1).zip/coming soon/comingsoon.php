<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>CodeOrbit | Coming Soon</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #0f0216;
            --accent-neon: #BFF747;
            --text-light: #ffffff;
            --text-muted: #a097a6;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            width: 100%;
            height: 100vh;
            background-color: var(--bg-dark);
            color: var(--text-light);
            font-family: 'Inter', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        /* ROCKET CONTAINER */
        .rocket-container {
            position: absolute;
            z-index: 20;
            transform: translateY(-120vh);
            opacity: 0;
        }

        .rocket-container.landed {
            opacity: 1;
            animation: rocketLand 1.4s cubic-bezier(0.25, 1, 0.5, 1) forwards;
        }

        @keyframes rocketLand {
            0% { transform: translateY(-120vh) scale(1.3); }
            80% { transform: translateY(-10px) scale(1); } 
            100% { transform: translateY(0) scale(1); } 
        }

        .flame { transform-origin: top center; animation: flicker 0.05s infinite alternate; }
        .flame.extinguish { animation: killFlame 0.15s forwards; }
        @keyframes flicker { 0% { transform: scaleY(0.8); opacity: 0.8; } 100% { transform: scaleY(1.3); opacity: 1; } }
        @keyframes killFlame { to { transform: scaleY(0); opacity: 0; } }

        .dust-ring {
            position: absolute;
            width: 120px; height: 30px;
            border: 2px solid var(--accent-neon);
            border-radius: 50%;
            transform: translate(0, 40px) scale(0);
            opacity: 0;
        }
        .dust-ring.expand { animation: dustExpand 0.7s ease-out forwards; }
        @keyframes dustExpand {
            0% { transform: translate(0, 40px) scale(0); opacity: 1; border-width: 3px; }
            100% { transform: translate(0, 40px) scale(2.5); opacity: 0; border-width: 0px; }
        }

        .rocket-container.fade-out { opacity: 0; transform: scale(0.85) translateY(15px); transition: all 0.4s ease; }

        /* BRAND UI */
        .ui-container {
            text-align: center;
            padding: 3rem;
            width: 90%;
            max-width: 620px;
            background: rgba(15, 2, 22, 0.65);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(191, 247, 71, 0.18);
            border-radius: 24px;
            opacity: 0;
            transform: scale(0.85) translateY(40px);
            transition: all 0.7s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .ui-container.visible { opacity: 1; transform: scale(1) translateY(0); }

        .status-badge { color: var(--accent-neon); margin-bottom: 1.5rem; text-transform: uppercase; letter-spacing: 2px; font-weight: 700; font-size: 0.8rem; }
        h1 { font-size: 3.8rem; margin-bottom: 1rem; }
        h1 span { color: var(--accent-neon); }
        .subtitle { color: var(--text-muted); margin-bottom: 2.5rem; min-height: 60px; }
        .cursor { color: var(--accent-neon); animation: blink 1s infinite; }
        @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }

        input { padding: 1rem 1.5rem; background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 50px; color: #fff; width: 60%; }
        button { padding: 1rem 2rem; background: var(--accent-neon); color: var(--bg-dark); border: none; border-radius: 50px; font-weight: 700; cursor: pointer; }
    </style>
</head>
<body>

    <div class="rocket-container" id="rocket">
        <svg width="60" height="100" viewBox="0 0 60 100">
            <path d="M30 0 C45 20 45 60 45 70 L15 70 C15 60 15 20 30 0Z" fill="rgba(191,247,71,0.1)" stroke="#BFF747" stroke-width="2"/>
            <path d="M15 50 L0 80 L15 70 Z" fill="#BFF747"/>
            <path d="M45 50 L60 80 L45 70 Z" fill="#BFF747"/>
            <circle cx="30" cy="35" r="7" fill="#0f0216" stroke="#BFF747" stroke-width="2"/>
            <path class="flame" id="rocketFlame" d="M26 80 L34 80 L30 100 Z" fill="#BFF747"/>
        </svg>
        <div class="dust-ring" id="dustRing"></div>
    </div>

    <div class="ui-container" id="mainUI">
        <div class="status-badge">System Initialized</div>
        <h1>Code<span>Orbit</span></h1>
        <p class="subtitle"><span id="typewriter"></span><span class="cursor">|</span></p>
        <form onsubmit="event.preventDefault(); alert('Transmission Received!');">
            <input type="email" placeholder="Enter email" required>
            <button type="submit">Join Waitlist</button>
        </form>
    </div>

    <script>
        window.onload = () => {
            // Trigger landing immediately
            setTimeout(() => { document.getElementById('rocket').classList.add('landed'); }, 500);
            
            // Extinguish flame and expand dust
            setTimeout(() => {
                document.getElementById('rocketFlame').classList.add('extinguish');
                document.getElementById('dustRing').classList.add('expand');
            }, 1900);

            // Show UI
            setTimeout(() => {
                const rocket = document.getElementById('rocket');
                rocket.classList.add('fade-out');
                document.getElementById('mainUI').classList.add('visible');
                startTypewriter();
            }, 2300);
        };

        function startTypewriter() {
            const phrases = ["Master complex programming theory.", "Solve practical coding problems.", "Accelerate your learning."];
            let phraseIdx = 0, charIdx = 0, isDeleting = false;
            const el = document.getElementById('typewriter');
            function type() {
                const cur = phrases[phraseIdx];
                el.textContent = isDeleting ? cur.substring(0, charIdx - 1) : cur.substring(0, charIdx + 1);
                charIdx = isDeleting ? charIdx - 1 : charIdx + 1;
                let speed = isDeleting ? 15 : 40;
                if (!isDeleting && charIdx === cur.length) { speed = 2000; isDeleting = true; }
                else if (isDeleting && charIdx === 0) { isDeleting = false; phraseIdx = (phraseIdx + 1) % phrases.length; }
                setTimeout(type, speed);
            }
            type();
        }
    </script>
</body>
</html>